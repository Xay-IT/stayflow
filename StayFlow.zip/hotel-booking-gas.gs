// ============================================================
//  🏨 Hotel Booking System — Google Apps Script
// ============================================================
//
//  ขั้นตอน:
//  1. Extensions → Apps Script → ลบโค้ดเก่า → วางโค้ดนี้ → Save
//  2. เลือก function "setupSheets" → กด ▶️ Run (ทำครั้งเดียว)
//  3. Deploy → New Deployment → Web App
//     - Execute as: Me  /  Who has access: Anyone
//  4. Copy Web App URL → วางในหน้าเว็บ
//
//  ⚠️  ถ้าแก้โค้ด → Manage deployments → Edit → New version → Deploy
//
//  Bookings columns (A–AH = 34 cols):
//   A  BookingNo      B  FirstName       C  LastName
//   D  Room           E  CheckIn         F  CheckOut
//   G  Status         H  Adults          I  Children
//   J  Infants        K  Price           L  Phone
//   M  Email          N  Nationality     O  Gender
//   P  DOB            Q  DocType         R  DocID
//   S  Address        T  Country         U  RatePlan
//   V  Reference      W  Channel         X  Company
//   Y  NightRates     Z  Services        AA ExtraGuests
//   AB Notes          AC CreatedAt       AD CompanyDetails
//   AE Birthplace     AF City            AG PostalCode
//   AH Comment (booker)  AI BookingComment
// ============================================================

function doGet(e) {
  const p = e.parameter, cb = p.callback || '', action = p.action || 'getAll';
  let result;
  try {
    if      (action === 'getAll')        result = getAllData();
    else if (action === 'exportData')    result = exportData(p);
    else if (action === 'addBooking')    result = addBooking(p);
    else if (action === 'updateBooking') result = updateBooking(p);
    else if (action === 'deleteBooking') result = deleteBooking(p);
    else if (action === 'getPartners')   result = getPartners();
    else if (action === 'addPartner')    result = addPartner(p);
    else if (action === 'updatePartner') result = updatePartner(p);
    else if (action === 'deletePartner') result = deletePartner_(p);
    else if (action === 'getGroups')    result = getGroups();
    else if (action === 'saveGroup')    result = saveGroup(p);
    else if (action === 'deleteGroup')  result = deleteGroup(p);
    else if (action === 'getSeasons')   result = getSeasons();
    else if (action === 'saveSeason')   result = saveSeason(p);
    else if (action === 'deleteSeason') result = deleteSeason_(p);
    else result = { ok: false, error: 'unknown action: ' + action };
  } catch (err) { result = { ok: false, error: err.toString() }; }
  const json = JSON.stringify(result);
  const body = cb ? cb + '(' + json + ')' : json;
  return ContentService.createTextOutput(body).setMimeType(ContentService.MimeType.JAVASCRIPT);
}

// ── decode base64 field ──
function dec_(v) {
  if (!v) return '';
  if (String(v).startsWith('b64:')) {
    try {
      return Utilities.newBlob(Utilities.base64Decode(String(v).slice(4))).getDataAsString('UTF-8');
    } catch(e) { return String(v); }
  }
  return String(v);
}

// ── human-readable formatters ──
function fmtNightRates_(j) {
  try {
    var a = JSON.parse(j||'[]');
    if (!a.length) return '';
    var lines = a.filter(function(r){ return r.date && r.price !== '' && r.price !== undefined; })
      .map(function(r){
        var d = r.date.slice(5).replace('-','/');
        return d + ': $' + r.price;
      });
    return lines.length ? lines.join(' | ') : '';
  } catch(e) { return ''; }
}
function fmtServices_(j) {
  try {
    var a = JSON.parse(j||'[]');
    if (!a.length) return '';
    return a.filter(function(r){return r.name;}).map(function(r){
      var d = r.date ? r.date.slice(5).replace('-','/') : '';
      return (d?d+' ':'')+r.name+' x'+(r.qty||1)+' $'+(r.price||0);
    }).join(' | ');
  } catch(e) { return ''; }
}
function fmtExtraGuests_(j) {
  try {
    var a = JSON.parse(j||'[]');
    if (!a.length) return '';
    var lines = [];

    // Primary slot — company details (legacy support)
    var primary = null;
    for (var pi=0; pi<a.length; pi++) { if (a[pi]._primary) { primary = a[pi]; break; } }
    if (primary) {
      var companyFields = [];
      if (primary.ccontact) companyFields.push('Contact: '  + primary.ccontact);
      if (primary.cphone)   companyFields.push('Phone: '    + primary.cphone);
      if (primary.cemail)   companyFields.push('Email: '    + primary.cemail);
      if (primary.caddress) companyFields.push('Address: '  + primary.caddress);
      var loc = [primary.ccity, primary.ccountry].filter(Boolean).join(', ');
      if (loc)              companyFields.push('Location: ' + loc);
      if (primary.cpostal)  companyFields.push('Postal: '   + primary.cpostal);
      if (primary.cregion)  companyFields.push('Region: '   + primary.cregion);
      if (primary.vat)      companyFields.push('VAT: '      + primary.vat);
      if (companyFields.length) {
        lines.push('[Company Details]');
        for (var ci=0; ci<companyFields.length; ci++) lines.push(companyFields[ci]);
      }
    }

    // Additional guests
    var guests = [];
    for (var gi=0; gi<a.length; gi++) {
      var r = a[gi];
      if (!r._primary && ((r.firstname||'').trim() || (r.lastname||'').trim() || (r.name||'').trim())) {
        guests.push(r);
      }
    }
    if (guests.length) {
      if (lines.length) lines.push('');
      lines.push('[Additional Guests]');
      for (var xi=0; xi<guests.length; xi++) {
        var g = guests[xi];
        var n = ((g.firstname||'')+' '+(g.lastname||'')).trim() || (g.name||'');
        lines.push((xi+1)+'. ' + n + (g.type ? ' ('+g.type+')' : ''));
        if (g.gender || g.dob)        lines.push('   ' + [g.gender, g.dob].filter(Boolean).join(' · '));
        if (g.birthplace)             lines.push('   Birthplace: ' + g.birthplace);
        if (g.nationality)            lines.push('   Nationality: ' + g.nationality);
        if (g.docType && g.docNumber) lines.push('   ' + g.docType + ': ' + g.docNumber);
        if (g.phone)                  lines.push('   Phone: ' + g.phone);
        if (g.email)                  lines.push('   Email: ' + g.email);
        var addr = [g.address, g.city, g.postal, g.country].filter(Boolean).join(', ');
        if (addr)                     lines.push('   Address: ' + addr);
        if (g.note)                   lines.push('   Comment: ' + g.note);
      }
    }

    return lines.join('\n');
  } catch(e) { return ''; }
}

function fmtCompanyDetails_(j) {
  try {
    var cd = JSON.parse(j || '{}');
    var lines = [];
    if (cd.ccontact) lines.push('Contact: '  + cd.ccontact);
    if (cd.cphone)   lines.push('Phone: '    + cd.cphone);
    if (cd.cemail)   lines.push('Email: '    + cd.cemail);
    if (cd.caddress) lines.push('Address: '  + cd.caddress);
    var loc = [cd.ccity, cd.ccountry].filter(Boolean).join(', ');
    if (loc)         lines.push('Location: ' + loc);
    if (cd.cpostal)  lines.push('Postal: '   + cd.cpostal);
    if (cd.cregion)  lines.push('Region: '   + cd.cregion);
    if (cd.vat)      lines.push('VAT: '      + cd.vat);
    return lines.join('\n');
  } catch(e) { return ''; }
}



function fmtNotes_(j) {
  try {
    var a = JSON.parse(j||'[]');
    var notes = a.filter(function(r){ return r.text && r.text.trim(); });
    if (!notes.length) return '';
    return notes.map(function(r){
      var d = r.ts ? r.ts.slice(0,10) : '';
      var edited = r.edited ? ' (edited)' : '';
      return (d ? '[' + d + ']' + edited + '\n' : '') + r.text.trim();
    }).join('\n----\n');
  } catch(e) { return String(j||''); }
}

// ── getAllData ──
function getAllData() {
  const ss     = SpreadsheetApp.getActiveSpreadsheet();
  const bSheet = ss.getSheetByName('Bookings');
  const rSheet = ss.getSheetByName('Rooms');
  if (!bSheet) return { ok:false, error:'ไม่พบชีท Bookings', bookings:[], rooms:[] };
  if (!rSheet) return { ok:false, error:'ไม่พบชีท Rooms',    bookings:[], rooms:[] };

  const lastRow = bSheet.getLastRow();
  const bData   = lastRow > 1 ? bSheet.getRange(2,1,lastRow-1,35).getValues() : [];
  const bNotes  = lastRow > 1 ? bSheet.getRange(2,25,lastRow-1,4).getNotes() : [];  // cols Y-AB notes

  const bookings = bData.filter(r => r[0]).map((r, rowIdx) => {
    const cellNotes = bNotes[rowIdx] || [];
    // Parse NightRates (col Y=24) and Services (col Z=25) and ExtraGuests (col AA=26)
    let nightRates=[], services=[], extraGuests=[];
    try {
      // Read raw JSON from cell note (new) or cell value (legacy [JSON] marker)
      var raw_nightRates = String(cellNotes[0] || r[24] || "");
      var ji_nightRates = raw_nightRates.indexOf("[JSON]");
      nightRates = JSON.parse(ji_nightRates >= 0 ? raw_nightRates.slice(ji_nightRates+6) : (raw_nightRates.trim().startsWith('[') ? raw_nightRates : '[]'));
    } catch(e){ nightRates = []; }
    try {
      var raw_services = String(cellNotes[1] || r[25] || "");
      var ji_services = raw_services.indexOf("[JSON]");
      services = JSON.parse(ji_services >= 0 ? raw_services.slice(ji_services+6) : (raw_services.trim().startsWith('[') ? raw_services : '[]'));
    } catch(e){ services = []; }
    try {
      var raw_extraGuests = String(cellNotes[2] || r[26] || "");
      var ji_extraGuests = raw_extraGuests.indexOf("[JSON]");
      extraGuests = JSON.parse(ji_extraGuests >= 0 ? raw_extraGuests.slice(ji_extraGuests+6) : (raw_extraGuests.trim().startsWith('[') ? raw_extraGuests : '[]'));
    } catch(e){ extraGuests = []; }

    // Parse Notes (col AB=27) as JSON array of {text,ts}
    let notes = [];
    try {
      var raw_nt = String(cellNotes[3] || r[27] || "");
      var ji_nt  = raw_nt.indexOf("[JSON]");
      notes = JSON.parse(ji_nt >= 0 ? raw_nt.slice(ji_nt+6) : (raw_nt.trim().startsWith('[') ? raw_nt : '[]'));
    } catch(e){ if(r[27]) notes=[{text:String(r[27]),ts:""}]; }

    const checkin  = r[4] ? Utilities.formatDate(new Date(r[4]),'Asia/Bangkok','yyyy-MM-dd') : '';
    const checkout = r[5] ? Utilities.formatDate(new Date(r[5]),'Asia/Bangkok','yyyy-MM-dd') : '';

    return {
      id:         String(r[0]  || ''),
      name:       String(r[1]  || '') + (r[2] ? ' ' + r[2] : ''),  // FirstName + LastName
      firstname:  String(r[1]  || ''),
      lastname:   String(r[2]  || ''),
      room:       String(r[3]  || ''),
      checkin,
      checkout,
      status:     String(r[6]  || 'รอยืนยัน'),
      guests:     Number(r[7]) || 1,
      price:      Number(r[10])|| 0,
      phone:      String(r[11] || ''),
      notes:      JSON.stringify(notes),  // keep notes as JSON string for client
      ext: {
        email:       String(r[12] || ''),
        nationality: String(r[13] || ''),
        gender:      String(r[14] || ''),
        dob:         r[15] ? Utilities.formatDate(new Date(r[15]), 'Asia/Bangkok', 'yyyy-MM-dd') : '',
        docType:     String(r[16] || ''),
        docNumber:   String(r[17] || ''),
        address:     String(r[18] || ''),
        country:     String(r[19] || ''),
        ratePlan:    String(r[20] || 'Standard'),
        reference:   String(r[21] || ''),
        channel:     String(r[22] || ''),
        company:     String(r[23] || ''),
        nightRates,
        services,
        extraGuests,
        firstname:   String(r[1]  || ''),
        lastname:    String(r[2]  || ''),
        guestAdult:  Number(r[7]) || 1,
        guestChild:  Number(r[8]) || 0,
        guestInfant: Number(r[9]) || 0,
        defaultNight: '',
        // CompanyDetails from col AD (r[29]) — partner/agent fields only
        ...( function() {
          var cd = {}; try { cd = JSON.parse(String(r[29]||'{}')); } catch(e){}
          var leg = (extraGuests[0] && extraGuests[0]._primary) ? extraGuests[0] : {};
          return {
            cpostal:    String(cd.cpostal    || leg.cpostal    || ''),
            ccity:      String(cd.ccity      || leg.ccity      || ''),
            ccountry:   String(cd.ccountry   || leg.ccountry   || ''),
            cregion:    String(cd.cregion    || leg.cregion    || ''),
            caddress:   String(cd.caddress   || leg.caddress   || ''),
            vat:        String(cd.vat        || leg.vat        || ''),
            ccontact:   String(cd.ccontact   || leg.ccontact   || ''),
            cphone:     String(cd.cphone     || leg.cphone     || ''),
            cemail:     String(cd.cemail     || leg.cemail     || ''),
          };
        })(),
        // Booker personal fields — separate cols AE-AH (r[30..33])
        birthplace: String(r[30] || ''),   // AE
        city:       String(r[31] || ''),   // AF
        postal:     String(r[32] || ''),   // AG
        note:       String(r[33] || ''),   // AH
        comment:    String(r[34] || ''),   // AI — BookingComment
      },
    };
  });

  const rLastRow = rSheet.getLastRow();
  const rData = rLastRow > 1 ? rSheet.getRange(2,1,rLastRow-1,6).getValues() : [];
  const rooms = rData.filter(r=>r[0]).map(r=>({
    id:String(r[0]||''), type:String(r[1]||''), price:Number(r[2])||0,
    capacity:Number(r[3])||2, floor:Number(r[4])||1, amenities:String(r[5]||''),
  }));

  return { ok:true, bookings, rooms };
}

// ── build row array (29 values) ──
function buildRow_(id, p, createdAt) {
  // Parse JSON fields sent from client
  let nightRates='', services='', extraGuests='', notesJson='';
  try { nightRates  = p.nightRates  || '[]'; JSON.parse(nightRates);  } catch(e){ nightRates='[]'; }
  try { services    = p.services    || '[]'; JSON.parse(services);    } catch(e){ services='[]'; }
  // ExtraGuests: only additional guests (no primary slot)
  let extraGuestsArr = [];
  try { extraGuestsArr = JSON.parse(p.extraGuests || '[]'); } catch(e){}
  // Strip any legacy _primary slot from extraGuests
  extraGuestsArr = extraGuestsArr.filter(function(g){ return !g._primary; });
  extraGuests = extraGuestsArr.length > 0 ? JSON.stringify(extraGuestsArr) : '[]';

  // CompanyDetails: booker's company info stored in separate column AD
  let companyDetails = '{}';
  // CompanyDetails: only c* fields (partner/agent info)
  const cd = {
    cpostal:    p.cpostal    || '',
    ccity:      p.ccity      || '',
    ccountry:   p.ccountry   || '',
    cregion:    p.cregion    || '',
    caddress:   dec_(p.caddress) || '',
    vat:        dec_(p.vat)      || '',
    ccontact:   dec_(p.ccontact) || '',
    cphone:     p.cphone         || '',
    cemail:     dec_(p.cemail)   || '',
  };
  const cdHasData = Object.values(cd).some(function(v){ return !!v; });
  companyDetails = cdHasData ? JSON.stringify(cd) : '{}';
  // Birthplace: booker personal info (separate cols AE-AH)
  const bd = {
    birthplace: p.birthplace || '',
    postal:     p.postal     || '',
    city:       p.city       || '',
    note:       dec_(p.note)    || '',
  };
  const bdHasData = Object.values(bd).some(function(v){ return !!v; });
  // Notes: client sends JSON array string
  try {
    const n = p.notes ? JSON.parse(dec_(p.notes)) : [];
    notesJson = JSON.stringify(Array.isArray(n) ? n : [{text:String(n),ts:''}]);
  } catch(e){ notesJson = p.notes ? JSON.stringify([{text:dec_(p.notes),ts:''}]) : '[]'; }

  return [
    id,
    dec_(p.firstname) || dec_(p.name || '').split(' ')[0] || '',  // B: FirstName
    dec_(p.lastname)  || dec_(p.name || '').split(' ').slice(1).join(' ') || '',  // C: LastName
    p.room     || '',           // D
    p.checkin  || '',           // E
    p.checkout || '',           // F
    p.status   || 'รอยืนยัน',  // G
    Number(p.guests)      || 1, // H Adults
    Number(p.guestChild)  || 0, // I Children
    Number(p.guestInfant) || 0, // J Infants
    Number(p.price)       || 0, // K Price
    dec_(p.phone)   || '',      // L Phone
    dec_(p.email)   || '',      // M Email
    p.nationality  || '',       // N
    p.gender       || '',       // O
    p.dob          || '',       // P DOB
    p.docType      || '',       // Q
    dec_(p.docNumber) || '',    // R
    dec_(p.address) || '',      // S
    p.country      || '',       // T
    p.ratePlan     || 'Master price', // U
    dec_(p.reference) || '',    // V
    p.channel      || '',       // W
    dec_(p.company) || '',      // X
    fmtNightRates_(nightRates)  || nightRates  || '',   // Y — human-readable
    fmtServices_(services)      || services    || '',   // Z — human-readable
    fmtExtraGuests_(extraGuests)|| extraGuests || '',   // AA — human-readable
    fmtNotes_(notesJson)        || notesJson   || '',   // AB — human-readable
    createdAt || new Date().toISOString(),              // AC
    fmtCompanyDetails_(companyDetails) || '',           // AD — CompanyDetails human-readable
    bd.birthplace || '',                               // AE — Birthplace
    bd.city       || '',                               // AF — City
    bd.postal     || '',                               // AG — PostalCode
    bd.note       || '',                               // AH — Comment (booker personal)
    dec_(p.comment) || '',                             // AI — BookingComment
  ];
}

// ── addBooking ──

function getRawJson_(p) {
  var nightRates  = '[]', services = '[]', extraGuests = '[]', notesJson = '[]';
  try { nightRates  = p.nightRates  || '[]'; JSON.parse(nightRates);  } catch(e){ nightRates='[]'; }
  try { services    = p.services    || '[]'; JSON.parse(services);    } catch(e){ services='[]'; }
  try {
    // Strip legacy _primary slots from extraGuests
    var egArr = JSON.parse(p.extraGuests || '[]').filter(function(g){ return !g._primary; });
    extraGuests = JSON.stringify(egArr);
  } catch(e){ extraGuests='[]'; }
  try {
    var notesRaw = p.notes ? dec_(p.notes) : null;
    if (notesRaw) {
      var n = JSON.parse(notesRaw);
      notesJson = JSON.stringify(Array.isArray(n) ? n : [{text:String(n),ts:''}]);
    }
  } catch(e){}
  // CompanyDetails
  var companyDetails = '{}';
  var cd = {
    cpostal:    p.cpostal    || '',
    ccity:      p.ccity      || '',
    ccountry:   p.ccountry   || '',
    cregion:    p.cregion    || '',
    caddress:   dec_(p.caddress) || '',
    vat:        dec_(p.vat)      || '',
    ccontact:   dec_(p.ccontact) || '',
    cphone:     p.cphone         || '',
    cemail:     dec_(p.cemail)   || '',
  };
  if (Object.values(cd).some(function(v){ return !!v; })) companyDetails = JSON.stringify(cd);
  return { nightRates:nightRates, services:services, extraGuests:extraGuests, notesJson:notesJson, companyDetails:companyDetails };
}

function addBooking(p) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Bookings');
  if (!sheet) return { ok:false, error:'ไม่พบชีท Bookings' };
  ensureCols_(sheet);

  // ── Duplicate guard: ตรวจสอบ room+checkin+checkout+firstname ซ้ำกันภายใน 60 วินาที ──
  const lastRow = sheet.getLastRow();
  if (lastRow >= 2) {
    const recent = sheet.getRange(2, 1, lastRow - 1, 29).getValues();
    const now = Date.now();
    for (let i = 0; i < recent.length; i++) {
      const r = recent[i];
      const createdAt = r[28] ? new Date(r[28]).getTime() : 0;
      if (now - createdAt < 60000) { // within 60 seconds
        const sameRoom     = String(r[3]) === String(p.room     || '');
        const sameCheckin  = String(r[4] ? Utilities.formatDate(new Date(r[4]), 'Asia/Bangkok', 'yyyy-MM-dd') : '') === String(p.checkin  || '');
        const sameCheckout = String(r[5] ? Utilities.formatDate(new Date(r[5]), 'Asia/Bangkok', 'yyyy-MM-dd') : '') === String(p.checkout || '');
        const sameName     = String(r[1]).toLowerCase() === String(dec_(p.firstname) || '').toLowerCase();
        if (sameRoom && sameCheckin && sameCheckout && sameName) {
          // Duplicate detected — return existing booking id instead of inserting
          return { ok:true, id: String(r[0]), _duplicate: true };
        }
      }
    }
  }

  const id  = 'BK-' + String(Date.now()).slice(-8);
  const row = buildRow_(id, p, new Date().toISOString());
  sheet.appendRow(row);
  try { sheet.getRange(sheet.getLastRow(),5,1,2).setNumberFormat('dd/mm/yyyy'); } catch(e){}
  try {
    var lr = sheet.getLastRow();
    var rj = getRawJson_(p);
    sheet.getRange(lr,25).setNote(rj.nightRates);
    sheet.getRange(lr,26).setNote(rj.services);
    sheet.getRange(lr,27).setNote(rj.extraGuests);
    sheet.getRange(lr,28).setNote(rj.notesJson);
    sheet.getRange(lr,30).setNote(rj.companyDetails);
  } catch(e){}
  return { ok:true, id };
}

// ── updateBooking ──
function updateBooking(p) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Bookings');
  if (!sheet) return { ok:false, error:'ไม่พบชีท Bookings' };
  ensureCols_(sheet);

  if (!p.id || String(p.id).startsWith('TMP-')) return addBooking(p);

  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return addBooking(p);

  const ids = sheet.getRange(2,1,lastRow-1,1).getValues();
  for (let i=0; i<ids.length; i++) {
    if (String(ids[i][0]) === String(p.id)) {
      // Preserve createdAt from existing row
      const existingCreatedAt = sheet.getRange(i+2, 29).getValue() || '';
      const row = buildRow_(p.id, p, existingCreatedAt || new Date().toISOString());
      sheet.getRange(i+2, 1, 1, 35).setValues([row]);
      try { sheet.getRange(i+2,5,1,2).setNumberFormat('dd/mm/yyyy'); } catch(e){}
      try {
        var ri = i+2;
        var rj = getRawJson_(p);
        sheet.getRange(ri,25).setNote(rj.nightRates);
        sheet.getRange(ri,26).setNote(rj.services);
        sheet.getRange(ri,27).setNote(rj.extraGuests);
        sheet.getRange(ri,28).setNote(rj.notesJson);
        sheet.getRange(ri,30).setNote(rj.companyDetails);
      } catch(e){}
      return { ok:true };
    }
  }
  // Not found → insert new
  return addBooking(p);
}

// ── deleteBooking ──
function deleteBooking(p) {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Bookings');
  if (!sheet) return { ok:false, error:'ไม่พบชีท Bookings' };
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return { ok:false, error:'ไม่มีข้อมูล' };
  const ids = sheet.getRange(2,1,lastRow-1,1).getValues();
  for (let i=0; i<ids.length; i++) {
    if (String(ids[i][0]) === String(p.id)) {
      sheet.deleteRow(i+2);
      return { ok:true };
    }
  }
  return { ok:false, error:'ไม่พบ id: ' + p.id };
}

// ── Partners ──
function getPartners() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Partners');
  if (!sheet) { Logger.log('Partners sheet not found'); return { ok:true, partners:[] }; }
  migratePartnersSheet_();
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  Logger.log('Partners: lastRow='+lastRow+' lastCol='+lastCol);
  if (lastRow < 2) return { ok:true, partners:[] };
  const headers = sheet.getRange(1,1,1,lastCol).getValues()[0].map(h=>String(h).toLowerCase().trim());
  Logger.log('Partners headers: '+JSON.stringify(headers));
  const col = (name, fallback) => { const i = headers.indexOf(name); return i>=0 ? i : fallback; };
  const cId      = col('partnerid',     0);
  const cName    = col('name',          1);
  const cType    = col('type',          2);
  const cContact = col('contactname',   3);
  const cPhone   = col('contactphone',  4);
  const cEmail   = col('contactemail',  5);
  const cAddress = col('address',       6);
  const cCity    = col('city',          7);
  const cPostal  = col('postalcode',    8);
  const cCountry = col('country',       9);
  const cRegion  = col('region',        10);
  const cVat     = col('vat',           11);
  const data = sheet.getRange(2,1,lastRow-1,lastCol).getValues();
  const partners = data
    .filter(r => r[cName] && String(r[cName]).trim())
    .map(r => ({
      id:       String(r[cId]      || ''),
      name:     String(r[cName]    || ''),
      type:     String(r[cType]    || ''),
      ccontact: String(r[cContact] || ''),
      cphone:   String(r[cPhone]   || ''),
      cemail:   String(r[cEmail]   || ''),
      caddress: String(r[cAddress] || ''),
      ccity:    String(r[cCity]    || ''),
      cpostal:  String(r[cPostal]  || ''),
      ccountry: String(r[cCountry] || ''),
      cregion:  String(r[cRegion]  || ''),
      vat:      String(r[cVat]     || ''),
    }));
  Logger.log('Partners found: '+partners.length);
  return { ok:true, partners };
}

function addPartner(p) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName('Partners');
  if (!sheet) sheet = setupPartnersSheet_();
  else migratePartnersSheet_(); // ensure columns exist
  const id = 'P-' + String(Date.now()).slice(-6);
  sheet.appendRow([
    id,
    p.name        || '',
    p.type        || '',
    dec_(p.ccontact)  || '',
    p.cphone      || '',
    dec_(p.cemail)    || '',
    dec_(p.caddress)  || '',
    p.ccity       || '',
    p.cpostal     || '',
    p.ccountry    || '',
    p.cregion     || '',
    dec_(p.vat)       || ''
  ]);
  return { ok:true, id };
}

function updatePartner(p) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Partners');
  if (!sheet) return { ok:false, error:'Partners sheet not found' };
  migratePartnersSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return { ok:false, error:'No partners found' };
  const data = sheet.getRange(2, 1, lastRow-1, 2).getValues(); // col A=id, B=name
  // Find by id first, then by name
  let rowIdx = -1;
  for (let i = 0; i < data.length; i++) {
    if (p.id && String(data[i][0]) === String(p.id)) { rowIdx = i+2; break; }
  }
  if (rowIdx < 0) {
    for (let i = 0; i < data.length; i++) {
      if (String(data[i][1]).toLowerCase() === String(p.name||'').toLowerCase()) { rowIdx = i+2; break; }
    }
  }
  if (rowIdx < 0) return addPartner(p); // not found — create new
  sheet.getRange(rowIdx, 1, 1, 12).setValues([[
    sheet.getRange(rowIdx, 1).getValue(), // keep existing PartnerID
    p.name        || '',
    sheet.getRange(rowIdx, 3).getValue(), // keep existing Type
    dec_(p.ccontact)  || '',
    p.cphone      || '',
    dec_(p.cemail)    || '',
    dec_(p.caddress)  || '',
    p.ccity       || '',
    p.cpostal     || '',
    p.ccountry    || '',
    p.cregion     || '',
    dec_(p.vat)       || ''
  ]]);
  return { ok:true, id: sheet.getRange(rowIdx, 1).getValue() };
}

// ── ensure 29-col header ──
function ensureCols_(sheet) {
  const fullHeaders = ['BookingNo','FirstName','LastName','Room','CheckIn','CheckOut','Status',
    'Adults','Children','Infants','Price','Phone','Email','Nationality','Gender',
    'DOB','DocType','DocID','Address','Country','RatePlan','Reference','Channel',
    'Company','NightRates','Services','ExtraGuests','Notes','CreatedAt','CompanyDetails',
    'Birthplace','City','PostalCode','Comment','BookingComment'];
  const lastCol = sheet.getLastColumn();
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1,1,1,34).setValues([fullHeaders]);
    sheet.getRange(1,1,1,34).setFontWeight('bold').setBackground('#1E3A5F').setFontColor('#FFFFFF');
    return;
  }
  // Ensure all 34 headers are correct (fixes renamed columns)
  const currentHeaders = sheet.getRange(1,1,1,Math.max(lastCol,35)).getValues()[0];
  for (var i=0; i<fullHeaders.length; i++) {
    if (currentHeaders[i] !== fullHeaders[i]) {
      sheet.getRange(1, i+1).setValue(fullHeaders[i])
        .setFontWeight('bold').setBackground('#1E3A5F').setFontColor('#FFFFFF');
    }
  }
}

// ============================================================
//  🔧 setupSheets()
// ============================================================
// Partners sheet columns (11):
// A:PartnerID  B:Name  C:Type
// D:ContactName  E:ContactPhone  F:ContactEmail
// G:Address  H:City  I:PostalCode  J:Country  K:Region  L:VAT
const PARTNER_HEADERS_ = [
  'PartnerID','Name','Type',
  'ContactName','ContactPhone','ContactEmail',
  'Address','City','PostalCode','Country','Region','VAT'
];

function setupPartnersSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.insertSheet('Partners');
  const n = PARTNER_HEADERS_.length;
  sheet.getRange(1,1,1,n).setValues([PARTNER_HEADERS_]);
  sheet.getRange(1,1,1,n).setBackground('#1E3A5F').setFontColor('#fff').setFontWeight('bold');
  sheet.setFrozenRows(1);
  // column widths
  sheet.setColumnWidth(1, 90);   // PartnerID
  sheet.setColumnWidth(2, 160);  // Name
  sheet.setColumnWidth(3, 110);  // Type
  sheet.setColumnWidth(4, 140);  // ContactName
  sheet.setColumnWidth(5, 130);  // ContactPhone
  sheet.setColumnWidth(6, 180);  // ContactEmail
  sheet.setColumnWidth(7, 200);  // Address
  sheet.setColumnWidth(8, 120);  // City
  sheet.setColumnWidth(9, 100);  // PostalCode
  sheet.setColumnWidth(10, 120); // Country
  sheet.setColumnWidth(11, 120); // Region
  sheet.setColumnWidth(12, 120); // VAT
  return sheet;
}

// Migrate existing Partners sheet to 12-column schema (non-destructive)
function migratePartnersSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Partners');
  if (!sheet) return setupPartnersSheet_();
  const cur = sheet.getLastColumn();
  if (cur >= PARTNER_HEADERS_.length) return sheet; // already up to date
  // Add missing header columns
  const headers = sheet.getRange(1,1,1,cur).getValues()[0].map(h => String(h).toLowerCase());
  for (let i = cur; i < PARTNER_HEADERS_.length; i++) {
    sheet.getRange(1, i+1).setValue(PARTNER_HEADERS_[i])
      .setBackground('#1E3A5F').setFontColor('#fff').setFontWeight('bold');
  }
  return sheet;
}


// ── Groups Sheet ──
function getGroups() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Groups');
  if (!sheet || sheet.getLastRow() < 2) return { ok:true, groups:[] };
  var data = sheet.getRange(2,1,sheet.getLastRow()-1,7).getValues();
  var groups = data.filter(function(r){ return r[0]; }).map(function(r){
    var bookingIds = [];
    try { bookingIds = JSON.parse(r[5]||'[]'); } catch(e){}
    return { id:String(r[0]), name:String(r[1]||''), leader:String(r[2]||''), discount:Number(r[3]||0), color:String(r[4]||'#7c3aed'), bookingIds:bookingIds, notes:String(r[6]||'') };
  });
  return { ok:true, groups:groups };
}

function saveGroup(p) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Groups');
  if (!sheet) {
    sheet = ss.insertSheet('Groups');
    sheet.getRange(1,1,1,7).setValues([['GroupID','Name','Leader','Discount%','Color','BookingIDs','Notes']]);
    sheet.getRange(1,1,1,7).setBackground('#1E3A5F').setFontColor('#fff').setFontWeight('bold');
    sheet.setFrozenRows(1);
  }
  var id = p.id || ('GRP-' + String(Date.now()).slice(-8));
  var bookingIds = p.bookingIds || '[]';
  // Find existing row
  var lastRow = sheet.getLastRow();
  var found = -1;
  if (lastRow > 1) {
    var ids = sheet.getRange(2,1,lastRow-1,1).getValues();
    for (var i=0; i<ids.length; i++) {
      if (String(ids[i][0]) === String(id)) { found = i+2; break; }
    }
  }
  var row = [id, p.name||'', p.leader||'', Number(p.discount||0), p.color||'#7c3aed', bookingIds, p.notes||''];
  if (found > 0) {
    sheet.getRange(found,1,1,7).setValues([row]);
  } else {
    sheet.appendRow(row);
  }
  return { ok:true, id:id };
}

function deleteGroup(p) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Groups');
  if (!sheet) return { ok:true };
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return { ok:true };
  var ids = sheet.getRange(2,1,lastRow-1,1).getValues();
  for (var i=ids.length-1; i>=0; i--) {
    if (String(ids[i][0]) === String(p.id||'')) {
      sheet.deleteRow(i+2); break;
    }
  }
  return { ok:true };
}


// ── Seasons Sheet ──
function getSeasons() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Seasons');
  if (!sheet || sheet.getLastRow() < 2) return { ok:true, seasons:[] };
  var data = sheet.getRange(2,1,sheet.getLastRow()-1,6).getValues();
  var seasons = data.filter(function(r){ return r[0]; }).map(function(r){
    var prices = {}, ratePlans = ['Standard'];
    try { prices = JSON.parse(r[4]||'{}'); } catch(e){}
    try { if (r[5]) ratePlans = JSON.parse(r[5]); } catch(e){}
    return { id:String(r[0]), name:String(r[1]||''), start:String(r[2]||''), end:String(r[3]||''), prices:prices, ratePlans:ratePlans };
  });
  return { ok:true, seasons:seasons };
}

function saveSeason(p) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Seasons');
  if (!sheet) {
    sheet = ss.insertSheet('Seasons');
    var hdr = [['SeasonID','Name','StartDate','EndDate','Prices (JSON)','RatePlans (JSON)']];
    sheet.getRange(1,1,1,6).setValues(hdr);
    sheet.getRange(1,1,1,6).setBackground('#1E3A5F').setFontColor('#fff').setFontWeight('bold');
    sheet.setFrozenRows(1);
    sheet.setColumnWidth(1,100); sheet.setColumnWidth(2,180);
    sheet.setColumnWidth(3,110); sheet.setColumnWidth(4,110); sheet.setColumnWidth(5,300);
    sheet.setColumnWidth(6,200);
  } else if (sheet.getLastColumn() < 6) {
    // Migrate old 5-column sheet — add RatePlans column
    sheet.getRange(1,6).setValue('RatePlans (JSON)');
    sheet.getRange(1,6).setBackground('#1E3A5F').setFontColor('#fff').setFontWeight('bold');
    sheet.setColumnWidth(6,200);
  }
  var id     = p.id || ('SN-' + String(Date.now()).slice(-8));
  var prices    = dec_(p.prices)    || '{}';
  var ratePlans = dec_(p.ratePlans) || '["Standard"]';
  // Normalize dates to yyyy-MM-dd
  var normDate = function(s) {
    if (!s) return '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    var d = new Date(s);
    if (isNaN(d)) return s;
    return Utilities.formatDate(d, 'UTC', 'yyyy-MM-dd');
  };
  var row = [id, p.name||'', normDate(p.start), normDate(p.end), prices, ratePlans];
  var lastRow = sheet.getLastRow();
  var found = -1;
  if (lastRow > 1) {
    var ids = sheet.getRange(2,1,lastRow-1,1).getValues();
    for (var i=0; i<ids.length; i++) {
      if (String(ids[i][0]) === String(id)) { found = i+2; break; }
    }
  }
  if (found > 0) sheet.getRange(found,1,1,6).setValues([row]);
  else sheet.appendRow(row);
  return { ok:true, id:id };
}

function deleteSeason_(p) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Seasons');
  if (!sheet) return { ok:true };
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return { ok:true };
  var ids = sheet.getRange(2,1,lastRow-1,1).getValues();
  for (var i=ids.length-1; i>=0; i--) {
    if (String(ids[i][0]) === String(p.id||'')) { sheet.deleteRow(i+2); break; }
  }
  return { ok:true };
}


function deletePartner_(p) {
  var ss    = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Partners');
  if (!sheet || sheet.getLastRow() < 2) return { ok:true };
  var lastRow = sheet.getLastRow();
  var data = sheet.getRange(2,1,lastRow-1,2).getValues(); // ID, Name
  for (var i = data.length-1; i >= 0; i--) {
    if ((p.id && String(data[i][0]) === String(p.id)) || String(data[i][1]) === String(p.name||'')) {
      sheet.deleteRow(i+2);
      return { ok:true };
    }
  }
  return { ok:true };
}

function setupSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // Bookings
  let bSheet = ss.getSheetByName('Bookings');
  if (!bSheet) bSheet = ss.insertSheet('Bookings');
  bSheet.clearContents();

  const headers = [['BookingNo','FirstName','LastName','Room','CheckIn','CheckOut','Status',
    'Adults','Children','Infants','Price','Phone','Email','Nationality','Gender',
    'DOB','DocType','DocID','Address','Country','RatePlan','Reference','Channel',
    'Company','NightRates','Services','ExtraGuests','Notes','CreatedAt','CompanyDetails',
    'Birthplace','City','PostalCode','Comment','BookingComment']];
  bSheet.getRange(1,1,1,35).setValues(headers);
  bSheet.getRange(1,1,1,35).setFontWeight('bold').setBackground('#1E3A5F')
    .setFontColor('#FFFFFF').setHorizontalAlignment('center');

  const colWidths = [100,120,120,120,100,100,110,60,70,60,80,110,160,110,70,
                     90,100,120,160,100,110,120,100,140,180,180,180,200,160,200,120,100,100,160,180];
  colWidths.forEach((w,i) => bSheet.setColumnWidth(i+1, w));
  bSheet.setFrozenRows(1);
  try { bSheet.getRange('E:F').setNumberFormat('dd/mm/yyyy'); } catch(e){}

  // Rooms
  let rSheet = ss.getSheetByName('Rooms');
  if (!rSheet) rSheet = ss.insertSheet('Rooms');
  rSheet.clearContents();
  rSheet.getRange(1,1,1,6).setValues([['RoomID','RoomType','PricePerNight','Capacity','Floor','Amenities']]);
  rSheet.getRange(1,1,1,6).setFontWeight('bold').setBackground('#1E3A5F')
    .setFontColor('#FFFFFF').setHorizontalAlignment('center');

  // Only write default room data if sheet is empty (preserves custom prices)
  if (rSheet.getLastRow() < 2) {
    const roomData = [
      ['Bungalow 1','Comfort',1021,2,1,'WiFi, Fan, Breakfast Inc.'],
      ['Bungalow 2','Comfort',1021,2,1,'WiFi, Fan, Breakfast Inc.'],
      ['Bungalow 3','Comfort',1021,2,1,'WiFi, Fan, Breakfast Inc.'],
      ['Bungalow 4','Comfort',1021,2,1,'WiFi, Fan, Breakfast Inc.'],
      ['Bungalow 5','Comfort',1021,2,1,'WiFi, Fan, Breakfast Inc.'],
      ['Bungalow 6','Deluxe', 1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 7','Deluxe', 1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 8','Comfort',1021,2,1,'WiFi, Fan, Breakfast Inc.'],
      ['Bungalow 9','Comfort',1021,2,1,'WiFi, Fan, Breakfast Inc.'],
      ['Bungalow 10','Deluxe',1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 11','Deluxe',1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 12','Deluxe',1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 13','Deluxe',1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 14','Deluxe',1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 15','Deluxe',1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 16','Deluxe',1021,2,1,'WiFi, A/C, Breakfast Inc.'],
      ['Bungalow 17','Sharing',1021,2,1,'No Breakfast, WiFi, Fan'],
    ];
    rSheet.getRange(2,1,roomData.length,6).setValues(roomData);
    for (let i=0; i<roomData.length; i++)
      rSheet.getRange(i+2,1,1,6).setBackground(i%2===0?'#F0F4FF':'#FFFFFF');
  }
  [120,100,130,90,70,220].forEach((w,i)=>rSheet.setColumnWidth(i+1,w));
  rSheet.setFrozenRows(1);

  // Partners
  if (!ss.getSheetByName('Partners')) setupPartnersSheet_();
  else migratePartnersSheet_(); // add new columns if missing

  Logger.log('✅ Setup done — Bookings (30 cols), Rooms (17), Partners');
  SpreadsheetApp.getUi().alert('✅ Setup done!\nBookings 30 columns, Rooms 17 ห้อง, Partners 12 columns พร้อมใช้งาน\n\nกรุณา Deploy ใหม่หลัง setup');
}

// ── exportData ──
// ส่ง raw rows จาก Sheet ตรงๆ พร้อม header
// params: dateFrom, dateTo (yyyy-MM-dd), statuses (comma-separated, optional)
function exportData(p) {
  var ss    = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Bookings');
  if (!sheet) return { ok: false, error: 'ไม่พบชีท Bookings' };

  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return { ok: true, headers: [], rows: [] };

  // Read header row (row 1) — 35 cols A..AI
  var headerRange = sheet.getRange(1, 1, 1, 35);
  var headers = headerRange.getValues()[0].map(function(h){ return String(h || ''); });

  // Read all data rows + cell notes (cols Y–AB = 25–28) for raw JSON
  var data     = sheet.getRange(2, 1, lastRow - 1, 35).getValues();
  var notes     = sheet.getRange(2, 25, lastRow - 1, 4).getNotes(); // Y,Z,AA,AB
  var notesAD   = sheet.getRange(2, 30, lastRow - 1, 1).getNotes(); // col AD = CompanyDetails JSON

  // Date filter
  var dateFrom = p.dateFrom || '';
  var dateTo   = p.dateTo   || '';

  // Status filter
  var allowedStatuses = null;
  if (p.statuses) {
    allowedStatuses = {};
    p.statuses.split(',').forEach(function(s){ allowedStatuses[s.trim()] = true; });
  }

  var rows = [];
  for (var i = 0; i < data.length; i++) {
    var r = data[i];
    if (!r[0]) continue; // skip empty rows

    // Format dates
    var checkin  = r[4]  ? Utilities.formatDate(new Date(r[4]),  'Asia/Bangkok', 'yyyy-MM-dd') : '';
    var checkout = r[5]  ? Utilities.formatDate(new Date(r[5]),  'Asia/Bangkok', 'yyyy-MM-dd') : '';
    var dob      = r[15] ? Utilities.formatDate(new Date(r[15]), 'Asia/Bangkok', 'yyyy-MM-dd') : '';

    // Date range filter on CheckIn
    if (dateFrom && checkin && checkin < dateFrom) continue;
    if (dateTo   && checkin && checkin > dateTo)   continue;

    // Status filter
    var status = String(r[6] || '');
    if (allowedStatuses && !allowedStatuses[status]) continue;

    // Compute nights
    var nights = '';
    if (checkin && checkout) {
      var ms = new Date(checkout) - new Date(checkin);
      if (ms > 0) nights = Math.round(ms / 86400000);
    }

    // Prefer raw JSON from cell notes for cols Y(24),Z(25),AA(26),AB(27)
    var cellNotes = notes[i] || [];
    var nightRatesRaw  = cellNotes[0] || String(r[24] || '');
    var servicesRaw    = cellNotes[1] || String(r[25] || '');
    var extraGuestsRaw = cellNotes[2] || String(r[26] || '');
    var notesRaw       = cellNotes[3] || String(r[27] || '');

    // Helper: parse JSON stored in notes (may have [JSON] prefix legacy)
    function parseNote(s) {
      var ji = s.indexOf('[JSON]');
      var src = ji >= 0 ? s.slice(ji + 6) : s;
      try { return JSON.parse(src.trim().startsWith('[') || src.trim().startsWith('{') ? src : '[]'); } catch(e) { return []; }
    }

    // Format NightRates → readable
    var nightRates = '';
    try {
      var nr = parseNote(nightRatesRaw);
      nightRates = Array.isArray(nr) ? nr.filter(function(x){return x.date;}).map(function(x){return x.date+': '+x.price;}).join(' | ') : '';
    } catch(e) { nightRates = nightRatesRaw; }

    // Format Services → readable
    var services = '';
    try {
      var sv = parseNote(servicesRaw);
      services = Array.isArray(sv) ? sv.filter(function(x){return x.name;}).map(function(x){
        var d = x.date ? x.date.slice(5).replace('-','/') + ' ' : '';
        return d + x.name + ' x' + (x.qty||1) + ' ฿' + (x.price||0);
      }).join(' | ') : '';
    } catch(e) { services = servicesRaw; }

    // Format ExtraGuests → readable (ALL fields)
    var extraGuests = '';
    try {
      var eg = parseNote(extraGuestsRaw);
      if (Array.isArray(eg)) {
        extraGuests = eg.filter(function(g){ return !g._primary; }).map(function(g, gi) {
          var name = ((g.firstname||'') + ' ' + (g.lastname||'')).trim() || g.name || '';
          var parts = [(gi+1) + '. ' + name];
          if (g.type)        parts.push('(' + g.type + ')');
          if (g.gender)      parts.push(g.gender);
          if (g.dob)         parts.push('DOB:' + g.dob);
          if (g.nationality) parts.push('NAT:' + g.nationality);
          if (g.docType && g.docNumber) parts.push(g.docType + ':' + g.docNumber);
          if (g.phone)       parts.push('Tel:' + g.phone);
          if (g.email)       parts.push('Email:' + g.email);
          if (g.birthplace)  parts.push('Birth:' + g.birthplace);
          var addr = [g.address, g.city, g.postal, g.country].filter(Boolean).join(', ');
          if (addr)          parts.push('Addr:' + addr);
          if (g.note)        parts.push('Note:' + g.note);
          return parts.join(' | ');
        }).join('\n');
      }
    } catch(e) { extraGuests = extraGuestsRaw; }

    // Format Notes → readable
    var notesText = '';
    try {
      var nt = parseNote(notesRaw);
      if (Array.isArray(nt)) {
        notesText = nt.filter(function(x){ return x.text && x.text.trim(); }).map(function(x){
          var d = x.ts ? '[' + x.ts.slice(0,10) + '] ' : '';
          return d + x.text.trim();
        }).join(' | ');
      } else { notesText = String(notesRaw || ''); }
    } catch(e) { notesText = String(notesRaw || ''); }

    // CompanyDetails: JSON stored in cell NOTE of col AD (col 30)
    // Cell value is human-readable text (fmtCompanyDetails_), note has raw JSON
    var cd = {};
    var cdRawNote = (notesAD[i] && notesAD[i][0]) ? String(notesAD[i][0]).trim() : '';
    var cdCellVal = String(r[29] || '').trim();

    // 1st try: note has raw JSON
    if (cdRawNote) {
      try { cd = JSON.parse(cdRawNote); } catch(e) { cd = {}; }
    }
    // 2nd try: cell value might be raw JSON (some legacy rows)
    if (!Object.values(cd).some(Boolean) && cdCellVal.startsWith('{')) {
      try { cd = JSON.parse(cdCellVal); } catch(e) { cd = {}; }
    }
    // 3rd try: cell value is human-readable "Contact: xxx\nPhone: yyy..."
    if (!Object.values(cd).some(Boolean) && cdCellVal) {
      var lines = cdCellVal.split('\n');
      lines.forEach(function(line) {
        var m;
        if ((m = line.match(/^Contact:\s*(.+)/i)))  cd.ccontact = m[1].trim();
        if ((m = line.match(/^Phone:\s*(.+)/i)))    cd.cphone   = m[1].trim();
        if ((m = line.match(/^Email:\s*(.+)/i)))    cd.cemail   = m[1].trim();
        if ((m = line.match(/^Address:\s*(.+)/i)))  cd.caddress = m[1].trim();
        if ((m = line.match(/^Location:\s*(.+)/i))) {
          var loc = m[1].split(',');
          cd.ccity    = (loc[0] || '').trim();
          cd.ccountry = (loc[1] || '').trim();
        }
        if ((m = line.match(/^Region:\s*(.+)/i)))   cd.cregion  = m[1].trim();
        if ((m = line.match(/^Postal:\s*(.+)/i)))   cd.cpostal  = m[1].trim();
        if ((m = line.match(/^VAT:\s*(.+)/i)))      cd.vat      = m[1].trim();
      });
    }

    rows.push([
      String(r[0]  || ''),   // A  BookingNo
      String(r[1]  || ''),   // B  FirstName
      String(r[2]  || ''),   // C  LastName
      String(r[3]  || ''),   // D  Room
      checkin,               // E  CheckIn
      checkout,              // F  CheckOut
      nights,                // –  Nights (computed)
      status,                // G  Status
      Number(r[7]) || '',    // H  Adults
      Number(r[8]) || '',    // I  Children
      Number(r[9]) || '',    // J  Infants
      Number(r[10])|| '',    // K  Price
      String(r[11] || ''),   // L  Phone
      String(r[12] || ''),   // M  Email
      String(r[13] || ''),   // N  Nationality
      String(r[14] || ''),   // O  Gender
      dob,                   // P  DOB
      String(r[16] || ''),   // Q  DocType
      String(r[17] || ''),   // R  DocID
      String(r[18] || ''),   // S  Address
      String(r[19] || ''),   // T  Country
      String(r[20] || ''),   // U  RatePlan
      String(r[21] || ''),   // V  Reference
      String(r[22] || ''),   // W  Channel
      String(r[23] || ''),   // X  Company
      nightRates,            // Y  NightRates
      services,              // Z  Services
      extraGuests,           // AA ExtraGuests
      notesText,             // AB Notes
      String(r[28] || ''),   // AC CreatedAt
      String(cd.ccontact  || ''), // AD CompanyContact
      String(cd.cphone    || ''), // AD CompanyPhone
      String(cd.cemail    || ''), // AD CompanyEmail
      String(cd.caddress  || ''), // AD CompanyAddress
      String(cd.ccity     || ''), // AD CompanyCity
      String(cd.ccountry  || ''), // AD CompanyCountry
      String(cd.cregion   || ''), // AD CompanyRegion
      String(cd.cpostal   || ''), // AD CompanyPostal
      String(cd.vat       || ''), // AD VAT
      String(r[30] || ''),   // AE Birthplace
      String(r[31] || ''),   // AF City
      String(r[32] || ''),   // AG PostalCode
      String(r[33] || ''),   // AH Comment
      String(r[34] || ''),   // AI BookingComment
    ]);
  }

  return { ok: true, headers: headers, rows: rows, count: rows.length };
}
